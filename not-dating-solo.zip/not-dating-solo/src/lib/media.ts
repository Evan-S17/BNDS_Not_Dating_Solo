import { S3Client, GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import crypto from "crypto";

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: process.env.S3_ENDPOINT,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || "",
  },
});

const allowedImageMime = new Set(["image/jpeg", "image/png", "image/webp"]);
const allowedVideoMime = new Set(["video/mp4", "video/webm"]);

export function validateMedia(contentType: string, fileSizeBytes: number) {
  const isImage = allowedImageMime.has(contentType);
  const isVideo = allowedVideoMime.has(contentType);
  if (!isImage && !isVideo) throw new Error("Unsupported media type.");
  if (isImage && fileSizeBytes > 10 * 1024 * 1024) throw new Error("Image exceeds 10 MB limit.");
  if (isVideo && fileSizeBytes > 50 * 1024 * 1024) throw new Error("Video exceeds 50 MB limit.");
  return { mediaType: isImage ? "IMAGE" : "VIDEO" } as const;
}

export function makeStorageKey(coupleId: string, fileName: string) {
  const ext = fileName.split(".").pop()?.toLowerCase() || "bin";
  return `private/couples/${coupleId}/${crypto.randomUUID()}.${ext}`;
}

export async function createSignedUploadUrl(storageKey: string, contentType: string) {
  const command = new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: storageKey,
    ContentType: contentType,
  });
  return getSignedUrl(s3, command, { expiresIn: 300 });
}

export async function createSignedReadUrl(storageKey: string) {
  const command = new GetObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: storageKey,
  });
  return getSignedUrl(s3, command, { expiresIn: 120 });
}
