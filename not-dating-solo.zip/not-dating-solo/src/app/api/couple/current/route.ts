import { auth } from "@/lib/auth";
import { ok, unauthorized, serverError } from "@/lib/http";
import { getActiveCoupleForUser } from "@/lib/pairing";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const couple = await getActiveCoupleForUser(session.user.id);
    return ok({ couple });
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
