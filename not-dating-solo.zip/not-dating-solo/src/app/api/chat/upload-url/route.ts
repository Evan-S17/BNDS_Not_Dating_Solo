import { auth } from "@/lib/auth";
import { badRequest, ok, unauthorized, serverError } from "@/lib/http";
import { createSignedUploadUrl, makeStorageKey, validateMedia } from "@/lib/media";
import { requireActiveCoupleMembership } from "@/lib/permissions";
import { uploadRequestSchema } from "@/lib/validators";

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const body = await req.json();
    const parsed = uploadRequestSchema.safeParse(body);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
    await requireActiveCoupleMembership(session.user.id, parsed.data.coupleId);
    validateMedia(parsed.data.contentType, parsed.data.fileSizeBytes);
    const storageKey = makeStorageKey(parsed.data.coupleId, parsed.data.fileName);
    const uploadUrl = await createSignedUploadUrl(storageKey, parsed.data.contentType);
    return ok({ uploadUrl, storageKey, uploadToken: storageKey, expiresIn: 300 });
  } catch (error) {
    console.error(error);
    return serverError(error instanceof Error ? error.message : "Internal server error");
  }
}
