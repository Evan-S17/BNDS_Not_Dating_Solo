"use client";

import { useRef, useState } from "react";

export function ChatComposer({ coupleId }: { coupleId: string }) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  async function sendText() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      await fetch("/api/chat/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ coupleId, type: "TEXT", textContent: text }),
      });
      setText("");
      location.reload();
    } finally {
      setBusy(false);
    }
  }

  async function uploadMedia(file: File) {
    setBusy(true);
    try {
      const uploadRes = await fetch("/api/chat/upload-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          coupleId,
          fileName: file.name,
          contentType: file.type,
          fileSizeBytes: file.size,
        }),
      });
      const uploadData = await uploadRes.json();
      if (!uploadRes.ok) throw new Error(uploadData.error || "Upload URL failed.");

      const putRes = await fetch(uploadData.uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": file.type },
        body: file,
      });
      if (!putRes.ok) throw new Error("Object storage upload failed.");

      const type = file.type.startsWith("image/") ? "IMAGE" : "VIDEO";
      const msgRes = await fetch("/api/chat/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ coupleId, type, uploadToken: uploadData.uploadToken }),
      });
      if (!msgRes.ok) {
        const data = await msgRes.json();
        throw new Error(data.error || "Message creation failed.");
      }

      location.reload();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mt-6 space-y-4 rounded border p-4">
      <div className="flex gap-3">
        <input className="flex-1 rounded border p-3" placeholder="Type a message" value={text} onChange={(e) => setText(e.target.value)} disabled={busy} />
        <button className="rounded bg-black px-4 py-2 text-white disabled:opacity-50" onClick={sendText} disabled={busy} type="button">Send</button>
      </div>
      <div className="flex items-center gap-3">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            await uploadMedia(file);
            if (fileInputRef.current) fileInputRef.current.value = "";
          }}
        />
        <button className="rounded border px-4 py-2 disabled:opacity-50" onClick={() => fileInputRef.current?.click()} disabled={busy} type="button">Upload photo/video</button>
        <span className="text-sm text-slate-500">Images up to 10 MB, videos up to 50 MB.</span>
      </div>
    </div>
  );
}
