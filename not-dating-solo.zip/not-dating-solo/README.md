# Not Dating Solo

GitHub-ready starter for a 1-day couple matching app.

## Included
- Next.js App Router
- Prisma + PostgreSQL schema
- Auth.js credentials login
- register/login/logout
- profile API
- 24-hour pairing logic
- private couple chat
- signed upload URL flow for photos/videos
- Contact Us and Update Log pages
- English/Chinese message stubs

## Important
This is a starter skeleton, not production-complete.

Before deploying, add at least:
- rate limiting
- email verification
- password reset
- abuse reporting / blocking
- malware scanning or moderation for uploads
- realtime transport if needed
- proper temporary upload-token persistence

## Run
```bash
npm install
cp .env.example .env
npm run db:generate
npm run db:push
npm run dev
```
