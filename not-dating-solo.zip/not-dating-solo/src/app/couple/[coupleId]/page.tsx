import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { createSignedReadUrl } from "@/lib/media";
import { requireActiveCoupleMembership } from "@/lib/permissions";
import { redirect } from "next/navigation";
import { ChatComposer } from "./ChatComposer";

async function getMessages(coupleId: string, userId: string) {
  await requireActiveCoupleMembership(userId, coupleId);
  const messages = await prisma.message.findMany({
    where: { coupleId },
    include: { sender: { select: { id: true, nickname: true } }, media: true },
    orderBy: { createdAt: "asc" },
  });
  return Promise.all(messages.map(async (m) => ({ ...m, mediaUrl: m.media ? await createSignedReadUrl(m.media.storageKey) : null })));
}

export default async function CouplePage({ params }: { params: Promise<{ coupleId: string }> }) {
  const { coupleId } = await params;
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  const messages = await getMessages(coupleId, session.user.id);

  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <h1 className="text-3xl font-bold">Couple Chat</h1>
      <p className="mt-2 text-slate-600">Private room for the active 1-day couple.</p>
      <div className="mt-8 rounded border p-4">
        <div className="space-y-3">
          {messages.map((message) => (
            <div key={message.id} className="rounded border p-3">
              <div className="text-sm font-semibold">{message.sender.nickname}</div>
              {(message.type === "TEXT" || message.type === "SYSTEM") && <p className="mt-1">{message.textContent}</p>}
              {message.type === "IMAGE" && message.mediaUrl && <img className="mt-2 max-h-80 rounded" src={message.mediaUrl} alt="uploaded media" />}
              {message.type === "VIDEO" && message.mediaUrl && <video className="mt-2 max-h-80 rounded" src={message.mediaUrl} controls preload="metadata" />}
            </div>
          ))}
        </div>
      </div>
      <ChatComposer coupleId={coupleId} />
    </main>
  );
}
