const updates = [
  {
    version: "0.1.0",
    date: "2026-04-01",
    text: "Initial full-stack starter: auth, profile, one-day pairing, secure media upload, couple chat, contact us.",
  },
];

export default function UpdatesPage() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="text-3xl font-bold">Update Log</h1>
      <div className="mt-6 space-y-4">
        {updates.map((item) => (
          <div key={item.version} className="rounded border p-4">
            <div className="flex items-center justify-between">
              <strong>{item.version}</strong>
              <span>{item.date}</span>
            </div>
            <p className="mt-2 text-slate-600">{item.text}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
