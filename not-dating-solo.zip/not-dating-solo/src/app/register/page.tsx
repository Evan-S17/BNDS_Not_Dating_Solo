"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "", nickname: "", language: "EN" });
  const [error, setError] = useState<string | null>(null);

  return (
    <main className="mx-auto max-w-md px-6 py-16">
      <h1 className="text-3xl font-semibold">Register</h1>
      <form
        className="mt-6 space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setError(null);
          const res = await fetch("/api/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(form),
          });
          if (!res.ok) {
            const data = await res.json();
            setError(data.error || "Registration failed.");
            return;
          }
          router.push("/login");
        }}
      >
        <input className="w-full rounded border p-3" placeholder="Email" value={form.email} onChange={(e) => setForm((s) => ({ ...s, email: e.target.value }))} />
        <input className="w-full rounded border p-3" placeholder="Password" type="password" value={form.password} onChange={(e) => setForm((s) => ({ ...s, password: e.target.value }))} />
        <input className="w-full rounded border p-3" placeholder="Nickname" value={form.nickname} onChange={(e) => setForm((s) => ({ ...s, nickname: e.target.value }))} />
        <select className="w-full rounded border p-3" value={form.language} onChange={(e) => setForm((s) => ({ ...s, language: e.target.value }))}>
          <option value="EN">English</option>
          <option value="ZH">中文</option>
        </select>
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
        <button className="w-full rounded bg-black p-3 text-white" type="submit">Create account</button>
      </form>
    </main>
  );
}
