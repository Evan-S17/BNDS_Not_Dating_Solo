import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { badRequest, ok, unauthorized, serverError } from "@/lib/http";
import { createSignedReadUrl } from "@/lib/media";
import { requireActiveCoupleMembership } from "@/lib/permissions";
import { mediaMessageSchema, textMessageSchema } from "@/lib/validators";

export async function GET(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const { searchParams } = new URL(req.url);
    const coupleId = searchParams.get("coupleId");
    if (!coupleId) return badRequest("Missing coupleId.");
    await requireActiveCoupleMembership(session.user.id, coupleId);
    const messages = await prisma.message.findMany({
      where: { coupleId },
      include: { media: true, sender: { select: { id: true, nickname: true, avatarUrl: true } } },
      orderBy: { createdAt: "asc" },
      take: 100,
    });
    const hydrated = await Promise.all(messages.map(async (message) => ({ ...message, mediaUrl: message.media ? await createSignedReadUrl(message.media.storageKey) : null })));
    return ok({ messages: hydrated });
  } catch (error) {
    console.error(error);
    return serverError();
  }
}

export async function POST(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const body = await req.json();
    if (body.type === "TEXT") {
      const parsed = textMessageSchema.safeParse(body);
      if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
      await requireActiveCoupleMembership(session.user.id, parsed.data.coupleId);
      const message = await prisma.message.create({
        data: { coupleId: parsed.data.coupleId, senderId: session.user.id, type: "TEXT", textContent: parsed.data.textContent },
      });
      return ok({ message }, 201);
    }
    const parsed = mediaMessageSchema.safeParse(body);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
    await requireActiveCoupleMembership(session.user.id, parsed.data.coupleId);
    const message = await prisma.message.create({
      data: {
        coupleId: parsed.data.coupleId,
        senderId: session.user.id,
        type: parsed.data.type,
        media: {
          create: {
            storageKey: parsed.data.uploadToken,
            originalName: "uploaded-file",
            mimeType: parsed.data.type === "IMAGE" ? "image/unknown" : "video/unknown",
            fileSizeBytes: 0,
          },
        },
      },
      include: { media: true },
    });
    return ok({ message }, 201);
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
