import { prisma } from "./db";
import { preferenceAccepts } from "./permissions";

export async function getActiveCoupleForUser(userId: string) {
  return prisma.couple.findFirst({
    where: {
      status: "ACTIVE",
      expiresAt: { gt: new Date() },
      OR: [{ userAId: userId }, { userBId: userId }],
    },
    include: { userA: true, userB: true },
  });
}

export async function pairUser(userId: string) {
  const existing = await getActiveCoupleForUser(userId);
  if (existing) return existing;

  const requester = await prisma.user.findUnique({ where: { id: userId } });
  if (!requester || requester.status !== "ACTIVE") throw new Error("User unavailable.");

  const candidates = await prisma.user.findMany({
    where: { id: { not: userId }, status: "ACTIVE" },
    orderBy: { createdAt: "asc" },
    take: 100,
  });

  for (const candidate of candidates) {
    const candidateActive = await getActiveCoupleForUser(candidate.id);
    if (candidateActive) continue;

    if (!preferenceAccepts(candidate.gender, requester.genderPreference)) continue;
    if (!preferenceAccepts(requester.gender, candidate.genderPreference)) continue;

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000);

    try {
      return await prisma.$transaction(async (tx) => {
        const requesterStillFree = await tx.couple.findFirst({
          where: {
            status: "ACTIVE",
            expiresAt: { gt: now },
            OR: [{ userAId: requester.id }, { userBId: requester.id }],
          },
        });
        if (requesterStillFree) return requesterStillFree;

        const candidateStillFree = await tx.couple.findFirst({
          where: {
            status: "ACTIVE",
            expiresAt: { gt: now },
            OR: [{ userAId: candidate.id }, { userBId: candidate.id }],
          },
        });
        if (candidateStillFree) throw new Error("Candidate no longer free.");

        return tx.couple.create({
          data: {
            userAId: requester.id,
            userBId: candidate.id,
            expiresAt,
            messages: {
              create: {
                senderId: requester.id,
                type: "SYSTEM",
                textContent: "Couple created. This relationship will expire in 24 hours.",
              },
            },
          },
          include: { userA: true, userB: true },
        });
      });
    } catch {
      continue;
    }
  }

  return null;
}
