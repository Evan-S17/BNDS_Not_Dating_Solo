import argon2 from "argon2";
import { prisma } from "@/lib/db";
import { badRequest, ok, serverError } from "@/lib/http";
import { registerSchema } from "@/lib/validators";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
    const existing = await prisma.user.findUnique({ where: { email: parsed.data.email } });
    if (existing) return badRequest("Email already in use.");
    const passwordHash = await argon2.hash(parsed.data.password, { type: argon2.argon2id });
    const user = await prisma.user.create({
      data: {
        email: parsed.data.email,
        passwordHash,
        nickname: parsed.data.nickname,
        language: parsed.data.language,
        gender: "PREFER_NOT_TO_SAY",
        genderPreference: "ANY",
      },
      select: { id: true, email: true, nickname: true },
    });
    return ok({ user }, 201);
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
