import { prisma } from "./db";

export async function requireActiveCoupleMembership(userId: string, coupleId: string) {
  const couple = await prisma.couple.findFirst({
    where: {
      id: coupleId,
      status: "ACTIVE",
      expiresAt: { gt: new Date() },
      OR: [{ userAId: userId }, { userBId: userId }],
    },
  });
  if (!couple) throw new Error("Not authorized for this couple.");
  return couple;
}

export function preferenceAccepts(targetGender: string, preference: string): boolean {
  return preference === "ANY" || preference === targetGender;
}
