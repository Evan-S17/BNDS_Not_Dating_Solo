import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { badRequest, ok, unauthorized, serverError } from "@/lib/http";
import { profileSchema } from "@/lib/validators";

export async function GET() {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const profile = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { id: true, email: true, nickname: true, avatarUrl: true, gender: true, genderPreference: true, selfDescription: true, language: true },
    });
    return ok({ profile });
  } catch (error) {
    console.error(error);
    return serverError();
  }
}

export async function PATCH(req: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const body = await req.json();
    const parsed = profileSchema.safeParse(body);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
    const profile = await prisma.user.update({
      where: { id: session.user.id },
      data: parsed.data,
      select: { id: true, email: true, nickname: true, avatarUrl: true, gender: true, genderPreference: true, selfDescription: true, language: true },
    });
    return ok({ profile });
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
