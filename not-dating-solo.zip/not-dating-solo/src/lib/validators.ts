import { z } from "zod";

export const genderEnum = z.enum([
  "MALE",
  "FEMALE",
  "WALMART_BAG",
  "ATTACK_HELICOPTER",
  "PREFER_NOT_TO_SAY",
  "NOT_INCLUDED",
]);

export const genderPreferenceEnum = z.enum([
  "MALE",
  "FEMALE",
  "WALMART_BAG",
  "ATTACK_HELICOPTER",
  "PREFER_NOT_TO_SAY",
  "NOT_INCLUDED",
  "ANY",
]);

export const languageEnum = z.enum(["EN", "ZH"]);

export const registerSchema = z.object({
  email: z.string().email().trim().toLowerCase(),
  password: z.string().min(10).max(128),
  nickname: z.string().min(2).max(40),
  language: languageEnum.default("EN"),
});

export const profileSchema = z.object({
  nickname: z.string().min(2).max(40),
  avatarUrl: z.string().url().max(500).nullable().optional(),
  gender: genderEnum,
  genderPreference: genderPreferenceEnum,
  selfDescription: z.string().max(500).nullable().optional(),
  language: languageEnum,
});

export const textMessageSchema = z.object({
  coupleId: z.string().min(1),
  type: z.literal("TEXT"),
  textContent: z.string().min(1).max(4000),
});

export const uploadRequestSchema = z.object({
  coupleId: z.string().min(1),
  fileName: z.string().min(1).max(255),
  contentType: z.string().min(1).max(100),
  fileSizeBytes: z.number().int().positive(),
});

export const mediaMessageSchema = z.object({
  coupleId: z.string().min(1),
  type: z.enum(["IMAGE", "VIDEO"]),
  uploadToken: z.string().min(1),
});

export const contactSchema = z.object({
  subject: z.string().min(1).max(120),
  message: z.string().min(1).max(5000),
});
