import { auth } from "@/lib/auth";
import { ok, unauthorized, serverError } from "@/lib/http";
import { pairUser } from "@/lib/pairing";

export async function POST() {
  try {
    const session = await auth();
    if (!session?.user?.id) return unauthorized();
    const couple = await pairUser(session.user.id);
    if (!couple) return ok({ status: "queued" });
    return ok({ status: "matched", couple: { id: couple.id, expiresAt: couple.expiresAt, userA: couple.userA, userB: couple.userB } });
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
