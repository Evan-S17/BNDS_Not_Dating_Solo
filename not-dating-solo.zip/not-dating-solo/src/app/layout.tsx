import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Not Dating Solo",
  description: "One-day temporary pairing web app.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
