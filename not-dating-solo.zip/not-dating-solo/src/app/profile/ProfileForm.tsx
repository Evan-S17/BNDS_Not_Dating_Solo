"use client";

import { useState } from "react";

type ProfileFormProps = {
  initial: {
    nickname: string;
    avatarUrl: string | null;
    gender: string;
    genderPreference: string;
    selfDescription: string | null;
    language: string;
  };
};

const genderOptions = ["MALE", "FEMALE", "WALMART_BAG", "ATTACK_HELICOPTER", "PREFER_NOT_TO_SAY", "NOT_INCLUDED"];
const preferenceOptions = [...genderOptions, "ANY"];

export function ProfileForm({ initial }: ProfileFormProps) {
  const [form, setForm] = useState({
    nickname: initial.nickname,
    avatarUrl: initial.avatarUrl ?? "",
    gender: initial.gender,
    genderPreference: initial.genderPreference,
    selfDescription: initial.selfDescription ?? "",
    language: initial.language
  });
  const [status, setStatus] = useState<string | null>(null);

  return (
    <form
      className="mt-6 space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        setStatus(null);
        const res = await fetch("/api/profile", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form)
        });
        const data = await res.json();
        setStatus(res.ok ? "Saved." : data.error || "Failed.");
      }}
    >
      <input className="w-full rounded border p-3" placeholder="Nickname" value={form.nickname} onChange={(e) => setForm((s) => ({ ...s, nickname: e.target.value }))} />
      <input className="w-full rounded border p-3" placeholder="Avatar URL" value={form.avatarUrl} onChange={(e) => setForm((s) => ({ ...s, avatarUrl: e.target.value }))} />
      <select className="w-full rounded border p-3" value={form.gender} onChange={(e) => setForm((s) => ({ ...s, gender: e.target.value }))}>
        {genderOptions.map((g) => <option key={g} value={g}>{g}</option>)}
      </select>
      <select className="w-full rounded border p-3" value={form.genderPreference} onChange={(e) => setForm((s) => ({ ...s, genderPreference: e.target.value }))}>
        {preferenceOptions.map((g) => <option key={g} value={g}>{g}</option>)}
      </select>
      <textarea className="w-full rounded border p-3" rows={5} placeholder="Self description" value={form.selfDescription} onChange={(e) => setForm((s) => ({ ...s, selfDescription: e.target.value }))} />
      <select className="w-full rounded border p-3" value={form.language} onChange={(e) => setForm((s) => ({ ...s, language: e.target.value }))}>
        <option value="EN">English</option>
        <option value="ZH">中文</option>
      </select>
      {status ? <p className="text-sm text-slate-600">{status}</p> : null}
      <button className="rounded bg-black px-4 py-2 text-white" type="submit">Save</button>
    </form>
  );
}
