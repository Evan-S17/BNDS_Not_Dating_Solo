import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { badRequest, ok, serverError } from "@/lib/http";
import { contactSchema } from "@/lib/validators";

export async function POST(req: Request) {
  try {
    const session = await auth();
    const body = await req.json();
    const parsed = contactSchema.safeParse(body);
    if (!parsed.success) return badRequest(parsed.error.issues[0]?.message || "Invalid input.");
    const contact = await prisma.contactRequest.create({
      data: {
        userId: session?.user?.id,
        email: session?.user?.email ?? null,
        subject: parsed.data.subject,
        message: parsed.data.message,
      },
    });
    return ok({ contact }, 201);
  } catch (error) {
    console.error(error);
    return serverError();
  }
}
