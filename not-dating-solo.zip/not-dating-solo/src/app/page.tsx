import Link from "next/link";

export default function HomePage() {
  return (
    <main className="mx-auto max-w-4xl px-6 py-16">
      <h1 className="text-4xl font-bold">Not Dating Solo</h1>
      <p className="mt-4 text-slate-600">
        A one-day couple matching app with private chat, image/video messages, bilingual UI, and secure auth.
      </p>
      <div className="mt-8 flex gap-4">
        <Link className="rounded bg-black px-4 py-2 text-white" href="/login">Login</Link>
        <Link className="rounded border px-4 py-2" href="/register">Register</Link>
        <Link className="rounded border px-4 py-2" href="/dashboard">Dashboard</Link>
      </div>
    </main>
  );
}
