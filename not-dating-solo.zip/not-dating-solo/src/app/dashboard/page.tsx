import Link from "next/link";
import { auth, signOut } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getActiveCoupleForUser } from "@/lib/pairing";

export default async function DashboardPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");
  const couple = await getActiveCoupleForUser(session.user.id);

  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="mt-2 text-slate-600">Manage profile, pairing, and chat.</p>
        </div>
        <form action={async () => { "use server"; await signOut({ redirectTo: "/" }); }}>
          <button className="rounded border px-4 py-2">Logout</button>
        </form>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <Link className="rounded border p-4" href="/profile">Profile</Link>
        <form action="/api/pairing/request" method="POST">
          <button className="w-full rounded border p-4 text-left">Pair Me</button>
        </form>
        <Link className="rounded border p-4" href="/contact">Contact Us</Link>
      </div>

      <section className="mt-10 rounded border p-6">
        <h2 className="text-xl font-semibold">Current Couple</h2>
        {!couple ? (
          <p className="mt-3 text-slate-600">No active couple.</p>
        ) : (
          <div className="mt-4 space-y-3">
            <p>Couple ID: {couple.id}</p>
            <p>Expires at: {couple.expiresAt.toISOString()}</p>
            <Link className="inline-block rounded bg-black px-4 py-2 text-white" href={`/couple/${couple.id}`}>Open Chatroom</Link>
          </div>
        )}
      </section>
    </main>
  );
}
