"use client";

import { useState } from "react";

export default function ContactPage() {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<string | null>(null);

  return (
    <main className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="text-3xl font-bold">Contact Us</h1>
      <form
        className="mt-6 space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setStatus(null);
          const res = await fetch("/api/contact", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ subject, message }),
          });
          const data = await res.json();
          setStatus(res.ok ? "Submitted." : data.error || "Failed.");
          if (res.ok) { setSubject(""); setMessage(""); }
        }}
      >
        <input className="w-full rounded border p-3" placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <textarea className="w-full rounded border p-3" placeholder="Message" rows={8} value={message} onChange={(e) => setMessage(e.target.value)} />
        {status ? <p className="text-sm text-slate-600">{status}</p> : null}
        <button className="rounded bg-black px-4 py-2 text-white" type="submit">Submit</button>
      </form>
    </main>
  );
}
