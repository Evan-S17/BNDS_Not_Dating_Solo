"use client";

import { useEffect, useState } from "react";

const genderOptions = ["MALE", "FEMALE", "WALMART_BAG", "ATTACK_HELICOPTER", "PREFER_NOT_TO_SAY", "NOT_INCLUDED"] as const;
const preferenceOptions = [...genderOptions, "ANY"] as const;

export default function ProfilePage() {
  const [form, setForm] = useState({
    nickname: "",
    avatarUrl: "",
    gender: "PREFER_NOT_TO_SAY",
    genderPreference: "ANY",
    selfDescription: "",
    language: "EN",
  });
  const [status, setStatus] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/profile").then(async (res) => {
      const data = await res.json();
      if (data.profile) {
        setForm({
          nickname: data.profile.nickname || "",
          avatarUrl: data.profile.avatarUrl || "",
          gender: data.profile.gender || "PREFER_NOT_TO_SAY",
          genderPreference: data.profile.genderPreference || "ANY",
          selfDescription: data.profile.selfDescription || "",
          language: data.profile.language || "EN",
        });
      }
    });
  }, []);

  return (
    <main className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="text-3xl font-bold">Profile</h1>
      <form
        className="mt-6 space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setStatus(null);
          const res = await fetch("/api/profile", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ...form, avatarUrl: form.avatarUrl || null, selfDescription: form.selfDescription || null }),
          });
          const data = await res.json();
          setStatus(res.ok ? "Saved." : data.error || "Save failed.");
        }}
      >
        <input className="w-full rounded border p-3" value={form.nickname} placeholder="Nickname" onChange={(e) => setForm((s) => ({ ...s, nickname: e.target.value }))} />
        <input className="w-full rounded border p-3" value={form.avatarUrl} placeholder="Avatar URL" onChange={(e) => setForm((s) => ({ ...s, avatarUrl: e.target.value }))} />
        <select className="w-full rounded border p-3" value={form.gender} onChange={(e) => setForm((s) => ({ ...s, gender: e.target.value }))}>
          {genderOptions.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select className="w-full rounded border p-3" value={form.genderPreference} onChange={(e) => setForm((s) => ({ ...s, genderPreference: e.target.value }))}>
          {preferenceOptions.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <textarea className="w-full rounded border p-3" rows={5} value={form.selfDescription} placeholder="Self description" onChange={(e) => setForm((s) => ({ ...s, selfDescription: e.target.value }))} />
        <select className="w-full rounded border p-3" value={form.language} onChange={(e) => setForm((s) => ({ ...s, language: e.target.value }))}>
          <option value="EN">English</option>
          <option value="ZH">中文</option>
        </select>
        {status ? <p className="text-sm text-slate-600">{status}</p> : null}
        <button className="rounded bg-black px-4 py-2 text-white" type="submit">Save</button>
      </form>
    </main>
  );
}
